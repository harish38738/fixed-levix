# Levix Android App — Notification-Based Automatic Transaction Capture

A real Android app (Kotlin + Gradle) that wraps the actual Levix PWA
(sourced from your `fixed-levix-main` repo export, including all real
`src/*.js` files) in a WebView, and adds native Android notification-based
automatic transaction capture.

---

## Build verification status (read this first)

This section is deliberately literal about what was and wasn't verified,
and how, per your request not to claim completeness just because code was
written.

### ✅ Verified, with evidence

**1. Dependencies confirmed to exist** — `src/utils/helpers.js`,
`src/core/storage.js`, `src/core/navigation.js`, `src/security/pin.js`,
`src/security/recovery.js`, `src/security/autolock.js`,
`src/tutorial/onboarding.js`, `src/core/boot.js` were all present in your
repo export and inspected directly. Confirmed `TODAY()`, `fmt()`, `gc()` are
defined in `helpers.js`; `DB.*` in `storage.js`; and — critically — that
`navigation.js`'s `go('set')` already calls `loadNotifSettings()`, which is
exactly where the new `atcLoadSettings()` hook was attached.

**2. JavaScript bridge — runtime tested, not just read.** Using jsdom with
the real `index.html` and real `src/*.js` files served over a local HTTP
server (avoids a jsdom-only `file://` "opaque origin" localStorage quirk
that doesn't occur in real browsers or WebView):
- **Normal browser/PWA** (`window.AndroidBridge` absent): zero console
  errors on boot; all new functions exist and safely no-op.
- **Simulated Android WebView** (`window.AndroidBridge` stubbed):
  zero console errors. A sample "₹350 debited … Swiggy" payload correctly
  rendered "Paid ₹350 to Swiggy · 🍛 Food" using your actual `gc()`/`fmt()`.
  A credit payload correctly rendered "Received ₹5,000 from Client Payment
  · 💰 Income". Add-flow prefill was confirmed by reading back the real
  `#aa`/`#an` field values and the `selCat` lexical variable (via `eval`,
  since it's a top-level `let`, not a `window` property) — both matched.
  Ignore was confirmed to hide the banner. The Settings section was
  confirmed to show/hide and reflect the stubbed bridge's return values
  correctly.

**3. Kotlin — compiled, not just reviewed.** No Android SDK/Gradle
distribution is reachable from this environment (no network access to
Google's Maven repo or Gradle's distribution servers), so `./gradlew build`
could not be run. Instead, minimal but signature-accurate stubs of the
Android/androidx/org.json APIs actually used were hand-written, and all 6
Kotlin files were compiled for real with `kotlinc`. This caught two genuine
issues, both fixed in the shipped files:
- `DetectionStore.kt`: `SharedPreferences.getString()`'s nullable return
  wasn't defensively handled — added explicit `?: "[]"` fallbacks.
- `AndroidManifest.xml` had a real bug: an XML comment contained `--`
  internally, which is invalid XML syntax. Fixed and re-validated as
  well-formed.
(One more "error" — `.lowercase()` needing Kotlin 1.5+ — was a false
positive from this sandbox's older local `kotlinc` 1.3; the project's own
`app/build.gradle.kts` pins Kotlin 1.9.24, where this is native.)

**4. Method-name cross-check.** Every `AndroidBridge.*` call made from
`index.html` (`isNotificationCaptureEnabled`, `setNotificationCaptureEnabled`,
`isNotificationAccessGranted`, `openNotificationAccessSettings`,
`getPendingDetections`, `markDetectionHandled`) has a matching
`@JavascriptInterface` method in `JsBridge.kt` with the same name and
compatible signature.

### ⚠️ NOT verified — do not assume these work yet

- **No real Gradle/Android build was run.** The Kotlin compile above used
  hand-written stubs, not the real `android.jar`. It catches logic/type/
  syntax errors in this project's own code, but cannot catch Gradle manifest
  merging issues, AGP-version-specific behavior, or anything that depends on
  the real Android framework's actual runtime behavior.
- **Never run on an emulator or physical device.** Notification capture
  itself, the Notification Access settings deep-link, and the live banner
  have not been exercised against a real Android notification from a real
  bank/UPI app.
- **Deduplication of repost/updated notifications** (a bank re-posting the
  same notification) is implemented via a 5-minute time-bucket hash but has
  only been reasoned about, not tested against real-world notification
  behavior from actual banking apps.
- **Multiple notifications referring to the same underlying transaction**
  (e.g. a bank SMS-style notification and a separate UPI app notification
  for the same payment) are only deduplicated if their parsed
  amount+merchant+package match within the same 5-minute bucket — two
  different source apps reporting the same transaction with different
  merchant text would NOT currently be recognized as duplicates. This is a
  known limitation, not yet handled.

**Bottom line: the bridge is real, wired, and has passed everything that
could be checked without an actual Android SDK/build environment or a
physical device. A genuine Gradle build and on-device test are still
required before you can call this feature complete.**

---

## How to open and build

1. Open Android Studio → File > Open... → select this `LevixApp` folder.
2. Let Gradle sync (downloads the Android Gradle Plugin, Kotlin plugin, and
   the two small AndroidX dependencies in `app/build.gradle.kts`).
3. Run on a device or emulator (minSdk 26 / Android 8.0+).
4. **This is the first real build** — watch for and report back any errors
   Android Studio surfaces that weren't (and couldn't be) caught by the
   stub-based check described above.

## How to install and use notification capture

1. Launch the app once — this registers `NotificationCaptureService` with
   the OS (it won't receive anything yet).
2. In Levix, go to **Settings → Automatic Transaction Capture**.
3. Tap **Manage Notification Access** → opens Android's real
   **Settings → Notification access** screen → find "Levix" → toggle it on.
4. Return to Levix (switching back refreshes the status label
   automatically) → label should read "✅ Granted".
5. Turn on **Enable Automatic Capture** (blocked until step 3 is done).
   Off by default — fully opt-in.
6. When a bank/UPI/wallet app posts a transaction notification, Levix's
   confirmation banner appears (live if open, or on next open) with
   **Add Expense / Edit / Ignore**. Nothing is saved automatically.
7. Turning the toggle off at any time also wipes any locally queued
   (not-yet-confirmed) detections.

---

## Files changed in this integration pass

| File | What changed |
|---|---|
| `app/src/main/assets/index.html` | Bridge integration (see below) — sourced from your actual repo export, not the earlier incomplete upload |
| `app/src/main/assets/src/**` | Copied verbatim from your repo export — real dependency files, previously missing |
| `app/src/main/java/com/levix/app/DetectionStore.kt` | Fixed: explicit `?: "[]"` fallback for nullable `SharedPreferences.getString()` (found via real compile) |
| `app/src/main/AndroidManifest.xml` | Fixed: invalid `--` inside an XML comment (found via XML validation) |
| `README.md` | Rewritten with this verification report |

`JsBridge.kt`, `MainActivity.kt`, `NotificationCaptureService.kt`,
`TransactionParser.kt`, `NotificationAccessHelper.kt` are unchanged from the
previous pass — they already compiled clean and their method signatures
already matched the JS side.

### `index.html` changes (all additive, same as previously described)

1. **Home screen**: new `#native-tx-banner`, styled identically to the
   existing `#clip-banner`, with Add Expense / Edit / Ignore buttons.
2. **Settings screen**: new "Automatic Transaction Capture" section
   (hidden unless `window.AndroidBridge` exists) with explanation copy,
   enable/disable toggle, access-status label, and a "Manage Notification
   Access" button.
3. **New script block**, inserted immediately after the existing clipboard
   capture IIFE, defining `window.LevixNative`,
   `window.onNotificationTransactionDetected`, the banner logic, and the
   settings-section logic — all defensively guarded so a normal
   browser/PWA load is completely unaffected.
4. **One-line hook** added inside the existing `loadNotifSettings()`
   function (already called by `go('set')` in `navigation.js`) to refresh
   the new settings section whenever the user opens Settings.

---

## Transaction flow (end to end)

```
Bank/UPI app posts a notification
        │
        ▼
NotificationCaptureService.onNotificationPosted()
        │  (only runs if capture is enabled in Levix settings)
        ▼
Package/keyword filter  →  not a payment notification? → dropped
        │
        ▼
TransactionParser.parse()
        │  failed/declined wording?            → dropped (never surfaced)
        │  refund/reversal wording?             → income, category "refund"
        │  credit wording?                      → income
        │  debit wording?                       → expense + guessed category
        │  none of the above?                   → dropped
        ▼
DetectionStore.isDuplicate(hash)?
        │  same package+amount+merchant within a 5-min bucket → dropped
        ▼
DetectionStore.addPending()  +  broadcast if Levix is foregrounded
        │
        ▼
MainActivity → evaluateJavascript("window.LevixNative.onTransactionDetected(...)")
   (or, on next app open: MainActivity.onResume() → pullPendingDetections())
        │
        ▼
Levix shows #native-tx-banner: "New Transaction Detected — ₹350 · Swiggy · Food"
        │
   ┌────┼─────────────┬───────────────┐
   ▼    ▼             ▼               ▼
 Add  Edit         Ignore        (queued behind it if
 (prefills          (dismisses,   another detection
 openAdd(),          native entry  arrives meanwhile)
 user reviews        purged incl.
 & saves)            raw text)
```

At no point does a detection get written to the ledger without the user
tapping Add/Edit and going through the normal add-expense screen.

---

## Privacy

- All parsing and matching happens on-device. Nothing is uploaded anywhere.
- Only structured fields (amount, merchant, category, type, timestamp,
  source app package name) are queued locally, plus the raw notification
  text — and only until the user confirms/edits/ignores that specific
  detection, at which point it's deleted.
- The dedupe ledger stores only short hashes with timestamps, pruned after
  48 hours — never notification content.
- Capture is off by default and requires two explicit steps: granting
  Android's Notification Access, and turning the Levix toggle on.
- Turning the toggle off immediately clears any locally queued detections.
