package com.levix.app

import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * NotificationListenerService access can't be requested via a normal runtime
 * permission dialog -- the OS requires the user to grant it manually in
 * Settings. This helper checks current status and opens that settings screen.
 */
object NotificationAccessHelper {

    fun isNotificationAccessGranted(ctx: Context): Boolean {
        val enabledListeners = Settings.Secure.getString(
            ctx.contentResolver, "enabled_notification_listeners"
        ) ?: return false
        return enabledListeners.contains(ctx.packageName)
    }

    fun openNotificationAccessSettings(ctx: Context) {
        val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    }
}
