package com.levix.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var liveDetectionReceiver: BroadcastReceiver

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true // required: Levix relies on localStorage
        }
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(JsBridge(this), "AndroidBridge")

        // Live push while the app is already open in the foreground.
        liveDetectionReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val json = intent?.getStringExtra(NotificationCaptureService.EXTRA_DETECTION_JSON) ?: return
                // Calls into the bridge hook inside index.html (see integration notes).
                webView.evaluateJavascript(
                    "window.LevixNative && window.LevixNative.onTransactionDetected(${escapeForJs(json)});",
                    null
                )
            }
        }
        LocalBroadcastManager.getInstance(this).registerReceiver(
            liveDetectionReceiver, IntentFilter(NotificationCaptureService.ACTION_NEW_DETECTION)
        )

        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        // Pull anything queued while the app/WebView wasn't running.
        webView.evaluateJavascript(
            "window.LevixNative && window.LevixNative.pullPendingDetections();", null
        )
    }

    override fun onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(liveDetectionReceiver)
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    private fun escapeForJs(json: String): String =
        "\"" + json.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
}
