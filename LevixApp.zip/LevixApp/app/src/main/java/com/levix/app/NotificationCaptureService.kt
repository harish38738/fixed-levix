package com.levix.app

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import org.json.JSONObject

/**
 * Flow implemented here:
 * Notification posted -> package/keyword filter -> parse -> drop failed txns ->
 * dedupe -> queue locally -> (if app is foreground) broadcast immediately to
 * MainActivity for live display.
 *
 * Only fires when the user has explicitly enabled capture in Levix settings
 * (DetectionStore.isCaptureEnabled) -- granting Android's notification access
 * is a separate, additional gate that Android itself enforces.
 */
class NotificationCaptureService : NotificationListenerService() {

    companion object {
        const val ACTION_NEW_DETECTION = "com.levix.app.NEW_DETECTION"
        const val EXTRA_DETECTION_JSON = "detection_json"

        // Known payment/banking/UPI/wallet apps. Extend as needed.
        private val PACKAGE_ALLOWLIST = setOf(
            "com.google.android.apps.nbu.paisa.user", // Google Pay
            "com.phonepe.app",
            "net.one97.paytm",
            "in.amazon.mShop.android.shopping", // Amazon Pay notifications ride on main app
            "com.whatsapp" // WhatsApp Pay notifications - filtered further by keyword below
        )

        // Fallback keyword heuristic for bank apps we haven't allowlisted by package name.
        private val KEYWORD_HINTS = Regex(
            """\b(?:debited|credited|upi|₹|inr|rs\.?\s?\d|a/c|txn|payment|refund)\b""",
            RegexOption.IGNORE_CASE
        )
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!DetectionStore.isCaptureEnabled(applicationContext)) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val combined = listOf(title, text, bigText).filter { it.isNotBlank() }.joinToString(" ")

        if (combined.isBlank()) return

        val pkg = sbn.packageName
        val looksRelevant = pkg in PACKAGE_ALLOWLIST || KEYWORD_HINTS.containsMatchIn(combined)
        if (!looksRelevant) return

        val parsed = TransactionParser.parse(combined, pkg, sbn.postTime) ?: return

        val hash = TransactionParser.dedupeHash(pkg, parsed.amount, parsed.merchant, parsed.timestamp)
        if (DetectionStore.isDuplicate(applicationContext, hash)) return
        DetectionStore.markSeen(applicationContext, hash)

        val json = JSONObject().apply {
            put("id", parsed.id)
            put("type", parsed.type)
            put("amount", parsed.amount)
            put("merchant", parsed.merchant)
            put("category", parsed.category)
            put("timestamp", parsed.timestamp)
            put("sourceApp", parsed.sourceApp)
            // rawText is included only for the pending-item lifetime (debugging aid in the
            // confirmation UI); it is deleted from the store the moment the user acts on it.
            put("rawText", parsed.rawText)
        }

        DetectionStore.addPending(applicationContext, json)

        // If Levix is currently open, push it live instead of waiting for next resume.
        val intent = Intent(ACTION_NEW_DETECTION).putExtra(EXTRA_DETECTION_JSON, json.toString())
        LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(intent)
    }
}
