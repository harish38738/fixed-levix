package com.levix.app

import java.util.*

data class ParsedTransaction(
    val id: String,
    val type: String,          // "expense" | "income"
    val amount: Double,
    val merchant: String,
    val category: String,
    val timestamp: Long,
    val sourceApp: String,
    val rawText: String        // kept only transiently -- never persisted long-term
)

/**
 * Direct Kotlin port of Levix's existing clipboard payment-capture regex engine
 * (see the "CLIPBOARD PAYMENT CAPTURE ENGINE" block in index.html), extended to
 * classify credits/refunds and to reject failed transactions outright.
 */
object TransactionParser {

    // Failed/declined transactions are ignored entirely
    private val FAILED_PATTERNS = listOf(
        Regex("""\b(failed|declined|not\s+processed|unsuccessful|insufficient\s+balance|txn\s+failed)\b""", RegexOption.IGNORE_CASE)
    )

    // Refunds/reversals: treated as income, category "refund"
    private val REFUND_PATTERNS = listOf(
        Regex("""(?:refund|reversed|refunded|credited\s+back)[^.]*?(?:of\s+)?(?:rs\.?|₹|inr)\s*([\d,]+(?:\.\d{1,2})?)""", RegexOption.IGNORE_CASE)
    )

    // Credits (income): salary, UPI received, deposits
    private val CREDIT_PATTERNS = listOf(
        Regex("""(?:inr|rs\.?|₹)\s*([\d,]+(?:\.\d{1,2})?)\s+credited[^.]*?(?:from|by)\s+([^\n.!,]{2,30})""", RegexOption.IGNORE_CASE),
        Regex("""(?:received|credited)\s+(?:inr|rs\.?|₹)\s*([\d,]+(?:\.\d{1,2})?)\s+from\s+([^\n.!,]{2,30})""", RegexOption.IGNORE_CASE)
    )

    // Debits (expense) -- same ordering as the JS PATTERNS array
    private val DEBIT_PATTERNS = listOf(
        Regex("""(?:you paid|paid|sent)\s+(?:rs\.?|₹)\s*([\d,]+(?:\.\d{1,2})?)\s+(?:to|at|for)\s+([^\n.!,]{2,30})""", RegexOption.IGNORE_CASE),
        Regex("""(?:inr|rs\.?|₹)\s*([\d,]+(?:\.\d{1,2})?)\s+debited[^.]*?(?:to|for|at)\s+([^\n.!,]{2,30})""", RegexOption.IGNORE_CASE),
        Regex("""(?:debited|deducted|spent)\s+(?:inr|rs\.?|₹)\s*([\d,]+(?:\.\d{1,2})?)\s+(?:from[^.]*?(?:for|to|at)|to)\s+([^\n.!,]{2,30})""", RegexOption.IGNORE_CASE),
        Regex("""(?:₹|rs\.?)\s*([\d,]+(?:\.\d{1,2})?)\s+(?:paid|sent|transferred)\s+to\s+([^\n.!,]{2,30})""", RegexOption.IGNORE_CASE),
        Regex("""(?:transaction|txn|payment)\s+of\s+(?:₹|rs\.?)\s*([\d,]+(?:\.\d{1,2})?)\s+(?:to|at|for)\s+([^\n.!,]{2,30})""", RegexOption.IGNORE_CASE),
        Regex("""(?:₹|rs\.?)\s*([\d,]+(?:\.\d{1,2})?)\s+to\s+([a-zA-Z][^\n.!,]{1,25})""", RegexOption.IGNORE_CASE)
    )

    private val MERCHANT_CATS = listOf(
        Regex("""\b(?:swiggy|zomato|dominos?|pizza|kfc|mcdon|restaurant|cafe|hotel|food|tea|coffee|biryani|mess|canteen)\b""", RegexOption.IGNORE_CASE) to "food",
        Regex("""\b(?:ola|uber|rapido|namma|metro|bus|train|flight|irctc|petrol|diesel|fuel|pump|bpcl|hpcl|iocl)\b""", RegexOption.IGNORE_CASE) to "travel",
        Regex("""\b(?:amazon|flipkart|myntra|meesho|ajio|nykaa|shopping|mart|store|shop|supermarket|dmart|big\s?bazaar)\b""", RegexOption.IGNORE_CASE) to "shopping",
        Regex("""\b(?:electricity|water|gas|broadband|wifi|internet|jio|airtel|vi|vodafone|bsnl|recharge|mobile|bill)\b""", RegexOption.IGNORE_CASE) to "bills",
        Regex("""\b(?:apollo|medplus|pharmacy|chemist|hospital|clinic|doctor|health|med|medicine|diagnostic)\b""", RegexOption.IGNORE_CASE) to "medical",
        Regex("""\b(?:netflix|prime|hotstar|spotify|youtube|gaming|game|movie|cinema|pvr|inox|ticket)\b""", RegexOption.IGNORE_CASE) to "entertainment",
        Regex("""\b(?:insurance|lic|policy|premium)\b""", RegexOption.IGNORE_CASE) to "insurance",
        Regex("""\b(?:school|college|tuition|course|udemy|books?|education|fees?)\b""", RegexOption.IGNORE_CASE) to "education"
    )

    private val MERCHANT_CUTOFF = Regex(
        """^(.*?)\s+(?:using|via|thru|through|towards|on|from|with|a/c|acc(?:ount)?|ref(?:erence)?|no\.?|txn|vpa|upi|id)\b""",
        RegexOption.IGNORE_CASE
    )

    /**
     * Returns null if the text isn't a recognizable payment notification,
     * or if it's a failed/declined transaction (these are deliberately dropped).
     */
    fun parse(rawText: String, sourceApp: String, postTime: Long): ParsedTransaction? {
        if (rawText.isBlank() || rawText.length > 800) return null
        if (FAILED_PATTERNS.any { it.containsMatchIn(rawText) }) return null // ignore failed txns

        // Refund/reversal -> income, category "refund"
        for (pat in REFUND_PATTERNS) {
            val m = pat.find(rawText) ?: continue
            val amt = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: continue
            if (amt < 1 || amt > 10_000_000) continue
            return build("income", amt, "Refund", "refund", sourceApp, postTime, rawText)
        }

        // Credit -> income
        for (pat in CREDIT_PATTERNS) {
            val m = pat.find(rawText) ?: continue
            val amt = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: continue
            if (amt < 1 || amt > 10_000_000) continue
            val merchant = cleanMerchant(m.groupValues[2])
            if (merchant.length < 2) continue
            return build("income", amt, merchant, "income", sourceApp, postTime, rawText)
        }

        // Debit -> expense
        for (pat in DEBIT_PATTERNS) {
            val m = pat.find(rawText) ?: continue
            val amt = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: continue
            if (amt < 1 || amt > 10_000_000) continue
            val merchant = cleanMerchant(m.groupValues[2])
            if (merchant.length < 2) continue
            return build("expense", amt, merchant, guessCategory(merchant), sourceApp, postTime, rawText)
        }

        return null
    }

    /** Stable dedupe key: same package + same amount + same merchant within a time bucket. */
    fun dedupeHash(sourceApp: String, amount: Double, merchant: String, postTime: Long): String {
        val bucket = postTime / (5 * 60 * 1000) // 5-minute bucket absorbs repost/update notifications
        return "$sourceApp|${"%.2f".format(amount)}|${merchant.lowercase()}|$bucket".hashCode().toString()
    }

    private fun cleanMerchant(raw: String): String {
        val cut = MERCHANT_CUTOFF.find(raw)
        val m = cut?.groupValues?.get(1) ?: raw
        return m.trim().replace(Regex("""\s+"""), " ").take(30)
    }

    private fun guessCategory(merchant: String): String =
        MERCHANT_CATS.firstOrNull { it.first.containsMatchIn(merchant) }?.second ?: "other"

    private fun build(
        type: String, amount: Double, merchant: String, category: String,
        sourceApp: String, postTime: Long, rawText: String
    ) = ParsedTransaction(
        id = UUID.randomUUID().toString(),
        type = type,
        amount = amount,
        merchant = merchant,
        category = category,
        timestamp = postTime,
        sourceApp = sourceApp,
        rawText = rawText
    )
}
