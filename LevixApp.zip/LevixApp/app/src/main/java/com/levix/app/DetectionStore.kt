package com.levix.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Local-only persistence for detected transactions awaiting user confirmation,
 * plus a rolling dedupe ledger so the same bank/UPI notification never surfaces
 * twice (banks frequently re-post/update the same notification).
 *
 * Nothing here is ever transmitted off-device. Raw notification text is kept
 * only until the user acts on the detection (confirm/edit/ignore), then purged.
 */
object DetectionStore {

    private const val PREFS = "levix_capture_prefs"
    private const val KEY_ENABLED = "capture_enabled"
    private const val KEY_PENDING = "pending_detections"
    private const val KEY_DEDUPE = "dedupe_hashes"
    private const val DEDUPE_MAX = 500
    private const val DEDUPE_TTL_MS = 48L * 60 * 60 * 1000 // 48h

    fun isCaptureEnabled(ctx: Context): Boolean =
        prefs(ctx).getBoolean(KEY_ENABLED, false) // opt-in by default: OFF

    fun setCaptureEnabled(ctx: Context, enabled: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_ENABLED, enabled).apply()
        if (!enabled) clearAll(ctx) // disabling wipes any queued local data
    }

    /** Returns true if this notification was already processed recently. */
    fun isDuplicate(ctx: Context, hash: String): Boolean {
        val arr = JSONArray(prefs(ctx).getString(KEY_DEDUPE, "[]") ?: "[]")
        val now = System.currentTimeMillis()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getString("h") == hash && now - o.getLong("t") < DEDUPE_TTL_MS) return true
        }
        return false
    }

    fun markSeen(ctx: Context, hash: String) {
        val arr = JSONArray(prefs(ctx).getString(KEY_DEDUPE, "[]") ?: "[]")
        val now = System.currentTimeMillis()
        val pruned = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (now - o.getLong("t") < DEDUPE_TTL_MS) pruned.put(o)
        }
        pruned.put(JSONObject().put("h", hash).put("t", now))
        while (pruned.length() > DEDUPE_MAX) pruned.remove(0)
        prefs(ctx).edit().putString(KEY_DEDUPE, pruned.toString()).apply()
    }

    /** Queue a parsed detection for the WebView to pick up (app may be closed). */
    fun addPending(ctx: Context, detection: JSONObject) {
        val arr = JSONArray(prefs(ctx).getString(KEY_PENDING, "[]") ?: "[]")
        arr.put(detection)
        prefs(ctx).edit().putString(KEY_PENDING, arr.toString()).apply()
    }

    /** Called by JsBridge when the WebView asks for anything queued. */
    fun getPending(ctx: Context): JSONArray =
        JSONArray(prefs(ctx).getString(KEY_PENDING, "[]") ?: "[]")

    /** Called after the user confirms/edits/ignores a specific detection in the UI. */
    fun removePending(ctx: Context, id: String) {
        val arr = JSONArray(prefs(ctx).getString(KEY_PENDING, "[]") ?: "[]")
        val kept = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getString("id") != id) kept.put(o)
        }
        prefs(ctx).edit().putString(KEY_PENDING, kept.toString()).apply()
    }

    fun clearAll(ctx: Context) {
        prefs(ctx).edit().remove(KEY_PENDING).remove(KEY_DEDUPE).apply()
    }

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
