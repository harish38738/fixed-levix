package com.levix.app

import android.webkit.JavascriptInterface
import androidx.appcompat.app.AppCompatActivity

/**
 * Every method here is callable from index.html as:
 *   AndroidBridge.methodName(args)
 *
 * This is the ONLY way native capabilities reach the Levix UI. It never
 * renders anything itself -- Levix's existing HTML/CSS/JS remains the UI.
 */
class JsBridge(private val activity: AppCompatActivity) {

    @JavascriptInterface
    fun isNotificationCaptureEnabled(): Boolean =
        DetectionStore.isCaptureEnabled(activity)

    @JavascriptInterface
    fun setNotificationCaptureEnabled(enabled: Boolean) {
        DetectionStore.setCaptureEnabled(activity, enabled)
    }

    @JavascriptInterface
    fun isNotificationAccessGranted(): Boolean =
        NotificationAccessHelper.isNotificationAccessGranted(activity)

    @JavascriptInterface
    fun openNotificationAccessSettings() {
        activity.runOnUiThread {
            NotificationAccessHelper.openNotificationAccessSettings(activity)
        }
    }

    /** Called by JS on load/resume to fetch anything queued while the app was closed. */
    @JavascriptInterface
    fun getPendingDetections(): String =
        DetectionStore.getPending(activity).toString()

    /** Called by JS once the user has confirmed/edited/ignored a specific detection. */
    @JavascriptInterface
    fun markDetectionHandled(id: String) {
        DetectionStore.removePending(activity, id)
    }

    /** Escape hatch: user wipes any queued native detections without touching expenses. */
    @JavascriptInterface
    fun clearAllDetections() {
        DetectionStore.clearAll(activity)
    }
}
